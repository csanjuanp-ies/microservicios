from http import HTTPStatus

import requests
from ms.db import db, Sdestino, Registro
from sqlalchemy.sql.expression import func
from ms.config import SRV_IP_VALIDATION, SRV_PORT_VALIDATION, URL_PATH_VALIDATION

import json


def validate_token(token):
    new_data = {
        'token': token,
    }
    url = f'http://{SRV_IP_VALIDATION}:{SRV_PORT_VALIDATION}{URL_PATH_VALIDATION}'
    try:
        respuesta = requests.get(url, params=new_data)
        return respuesta.status_code
    except:
        return HTTPStatus.FORBIDDEN


def get_destinos():
    destinos = Sdestino.query.all()
    data = ""
    for destino in destinos:
        data += str(destino) + ','
    return "[" + data[:-1] + "]"  # eliminando la coma final de más


def get_rows():
    rows = Registro.query.all()
    data = ""
    for row in rows:
        data += str(row) + ','
    return "[" + data[:-1] + "]"  # eliminando la coma final de más


def get_row(identificador):
    row = Registro.query.filter_by(referencia=identificador).first()
    data = ""
    if row:
        data = str(row)
        return HTTPStatus.OK, "[" + data + "]"

    return HTTPStatus.NOT_FOUND, data


def insert_row(data):
    referencia = 0
    if db.session.query(func.max(Registro.referencia)).scalar() is not None:
        referencia = db.session.query(func.max(Registro.referencia)).scalar() + 1

    new_row = Registro(
        referencia=referencia,
        fecha=data['fecha'].strftime('%Y-%m-%d'),
        destino=data['destino'],
        destinootro=data['destinootro'],
        interesado=data['interesado'],
        observaciones=data['observaciones'],
        fecham=data['fecham'].strftime('%Y-%m-%d'),
        mmod=data['mmod'],
    )

    try:
        db.session.add(new_row)
        db.session.commit()
    except:
        return HTTPStatus.FORBIDDEN

    return HTTPStatus.OK


def update_row(identificador, data):
    row = Registro.query.filter_by(referencia=identificador).first()
    if row:
        row.fecha=data['fecha'].strftime('%Y-%m-%d')
        row.destino=data['destino']
        row.destinootro=data['destinootro']
        row.interesado=data['interesado']
        row.observaciones=data['observaciones']
        row.fecham=data['fecham'].strftime('%Y-%m-%d')
        row.mmod=data['mmod']

        try:
            db.session.commit()
        except:
            return HTTPStatus.FORBIDDEN
        return HTTPStatus.OK

    return HTTPStatus.FORBIDDEN
