import os
from flask_sqlalchemy import SQLAlchemy


DB_USER = os.environ.get('DB_USER', 'log')
DB_PW = os.environ.get('DB_PW', 'log')
DB_SRV = os.environ.get('DB_SRV', 'localhost')
DB_BBDD = os.environ.get('DB_BBDD', 'rsalida')
DB_URI = f"mysql://{DB_USER}:{DB_PW}@{DB_SRV}/{DB_BBDD}"
db_config = {
    'SQLALCHEMY_DATABASE_URI': DB_URI,
    'SQLALCHEMY_TRACK_MODIFICATIONS': False,
}

db = SQLAlchemy()

def xstr(s):
    if s is None:
        return ''
    else:
        return str(s)



class Sdestino(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    descri = db.Column(db.String(50), nullable=False)

    def __str__(self):
        return "{\"id\":" + str(self.id) + ", \"descri\":\"" + self.descri + "\"}"


class Registro(db.Model):
    referencia = db.Column(db.Integer(), primary_key=True)
    fecha = db.Column(db.String(25), nullable=False)
    destino = db.Column(db.Integer(), nullable=False)
    destinootro = db.Column(db.String(50), nullable=False)
    interesado = db.Column(db.String(50), nullable=False)
    observaciones = db.Column(db.Text)
    fecham = db.Column(db.String(25))
    mmod = db.Column(db.Integer())

    def __str__(self):
        return "{\"referencia\":\"" + xstr(self.referencia) + \
               "\", \"fecha\":\"" + xstr(self.fecha) + \
               "\", \"destino\":\"" + xstr(self.destino) + \
               "\", \"destinootro\":\"" + xstr(self.destinootro) + \
               "\", \"interesado\":\"" + xstr(self.interesado) + \
               "\", \"observaciones\":\"" + xstr(self.observaciones) + \
               "\", \"fecham\":\"" + xstr(self.fecham) + \
               "\", \"mmod\":\"" + xstr(self.mmod) + \
               "\"}"
