from datetime import datetime
from http import HTTPStatus
from flask_restx import Namespace, Resource, abort
from flask import request, make_response
from ms.models import return_payload
from ms.lib import validate_token, get_destinos, get_rows, get_row, insert_row, update_row
from flask_restx import reqparse

api_namespace = Namespace('api', description='User API operations')

return_payload_model = api_namespace.model('Return', return_payload)



@api_namespace.route('/v1/get_destinos/')
class GetDestinosMs(Resource):
    @api_namespace.doc('get_destinos')
    @api_namespace.doc(params={'token': 'Token de usuario'})
    @api_namespace.response(200, 'Destinos', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        token = request.args.get("token", None)
        code = validate_token(token)
        if code == HTTPStatus.OK:
            return_payload['message'] = get_destinos()
            return return_payload
        abort(code)


@api_namespace.route('/v1/get_rows/')
class GetRowsMs(Resource):
    @api_namespace.doc('get_rows')
    @api_namespace.doc(params={'token': 'Token de usuario'})
    @api_namespace.response(200, 'Get Rows', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        token = request.args.get("token", None)
        code = validate_token(token)
        if code == HTTPStatus.OK:
            return_payload['message'] = get_rows()
            return return_payload
        abort(code)


@api_namespace.route('/v1/get_rows/<int:id>/')
class GetRowsByIdMs(Resource):
    @api_namespace.doc('get_rows_by_id')
    @api_namespace.doc(params={'token': 'Token de usuario'})
    @api_namespace.response(200, 'Get Rows by id', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self, id):
        token = request.args.get("token", None)
        code = validate_token(token)
        if code == HTTPStatus.OK:
            code_row, row = get_row(id)
            if code_row == HTTPStatus.OK:
                return_payload['message'] = row
                return return_payload
            abort(code_row)
        abort(code)


@api_namespace.route('/v1/insert_row/')
class InsertRowMs(Resource):
    @api_namespace.doc('insert_rows')
    @api_namespace.doc(params={'token': 'Token de usuario',
                               'fecha': 'fecha',
                               'destino': 'destino',
                               'destinootro': 'destinootro',
                               'interesado': 'interesado',
                               'observaciones': 'observaciones',
                               'fecham': 'fecham',
                               'mmod': 'mmod'
                               })
    @api_namespace.response(200, 'Insert rows', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        token = request.args.get("token", None)
        code = validate_token(token)
        if code == HTTPStatus.OK:
            parser = reqparse.RequestParser()
            parser.add_argument('fecha', type=lambda x: datetime.strptime(x, '%Y-%m-%d'), required=True, help='Fecha')
            parser.add_argument('destino', type=int, required=True, help='destino')
            parser.add_argument('destinootro', type=str, help='destinootro')
            parser.add_argument('interesado', type=str, required=True, help='interesado')
            parser.add_argument('observaciones', type=str, help='observaciones')
            parser.add_argument('fecham', type=lambda x: datetime.strptime(x, '%Y-%m-%d'), help='fecham')
            parser.add_argument('mmod', type=str, help='mmod')

            args = parser.parse_args()

            code_row = insert_row(args)
            if code_row == HTTPStatus.OK:
                return_payload['message'] = HTTPStatus.OK
                return return_payload
            abort(code_row)
        abort(code)


@api_namespace.route('/v1/update_row/<int:id>/')
class InsertRowMs(Resource):
    @api_namespace.doc('update_rows')
    @api_namespace.doc(params={'token': 'Token de usuario',
                               'id': 'id',
                               'fecha': 'fecha',
                               'destino': 'destino',
                               'destinootro': 'destinootro',
                               'interesado': 'interesado',
                               'observaciones': 'observaciones',
                               'fecham': 'fecham',
                               'mmod': 'mmod'
                               })
    @api_namespace.response(200, 'Update rows', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self, id):
        token = request.args.get("token", None)
        code = validate_token(token)
        if code == HTTPStatus.OK:
            parser = reqparse.RequestParser()
            parser.add_argument('fecha', type=lambda x: datetime.strptime(x, '%Y-%m-%d'), required=True, help='Fecha')
            parser.add_argument('destino', type=int, required=True, help='destino')
            parser.add_argument('destinootro', type=str, help='destinootro')
            parser.add_argument('interesado', type=str, required=True, help='interesado')
            parser.add_argument('observaciones', type=str, help='observaciones')
            parser.add_argument('fecham', type=lambda x: datetime.strptime(x, '%Y-%m-%d'), help='fecham')
            parser.add_argument('mmod', type=str, help='mmod')

            args = parser.parse_args()

            code_row = update_row(id, args)
            if code_row == HTTPStatus.OK:
                return_payload['message'] = HTTPStatus.OK
                return return_payload
            abort(code_row)
        abort(code)
