from flask_restx import fields


return_payload = {
    'message': fields.String()
}
