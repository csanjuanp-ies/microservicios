import os

# Tiempo en minutos de validación del token
SRV_IP = os.environ.get('SRV_IP', '127.0.0.1')
SRV_PORT = os.environ.get('SRV_PORT', '15001')
SRV_IP_VALIDATION = os.environ.get('SRV_IP_VALIDATION', '127.0.0.1')
SRV_PORT_VALIDATION = os.environ.get('SRV_PORT_VALIDATION', '15000')
URL_PATH_VALIDATION = '/api/v1/validate/'