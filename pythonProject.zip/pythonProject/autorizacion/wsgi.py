from auth.app import create_app
from auth.config import SRV_PORT, SRV_IP
application = create_app()


if __name__ == '__main__':
    application.run(host=SRV_IP, port=SRV_PORT)
