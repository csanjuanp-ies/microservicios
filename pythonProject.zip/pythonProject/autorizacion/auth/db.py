import os

from flask_sqlalchemy import SQLAlchemy


DB_USER = os.environ.get('DB_USER', 'log')
DB_PW = os.environ.get('DB_PW', 'log')
DB_SRV = os.environ.get('DB_SRV', 'localhost')
DB_BBDD = os.environ.get('DB_BBDD', 'autorizacion')
DB_URI = f"mysql://{DB_USER}:{DB_PW}@{DB_SRV}/{DB_BBDD}"
db_config = {
    'SQLALCHEMY_DATABASE_URI': DB_URI,
    'SQLALCHEMY_TRACK_MODIFICATIONS': False,
}

db = SQLAlchemy()


class Logins(db.Model):
    USUARIO = 'U'
    ADMIN = 'A'
    login = db.Column(db.String(255), primary_key=True)
    pasw = db.Column(db.String(255), nullable=False)
    tipo = db.Column(db.String(1), default=USUARIO)
    token = db.Column(db.Text)



