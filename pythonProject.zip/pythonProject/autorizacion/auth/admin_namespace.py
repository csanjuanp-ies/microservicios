from http import HTTPStatus
from flask_restx import Namespace, Resource, abort
from flask import request
from auth.config import PUBLIC_KEY, PRIVATE_KEY
from auth.models import return_payload
from auth.token_validation import generate_token_admin, validate_token_admin
from auth.db import db, Logins

admin_namespace = Namespace('admin', description='Admin API operations')

return_payload_model = admin_namespace.model('Return', return_payload)


@admin_namespace.route('/login/', methods=['POST'])
class LoginAdminMs(Resource):
    @admin_namespace.doc('login')
    @admin_namespace.doc(params={'user': 'Nombre de usuario', 'pass': 'Clave'})
    @admin_namespace.response(200, 'Token creado', return_payload_model)
    @admin_namespace.response(403, 'Error de acceso', return_payload_model)
    @admin_namespace.marshal_with(return_payload_model)
    def post(self):
        us = request.form.get("user", None)
        pw = request.form.get("pass", None)

        code, token = generate_token_admin(us, pw, PRIVATE_KEY)
        if code == HTTPStatus.OK:
            return_payload['message'] = token
            return return_payload

        abort(code)


@admin_namespace.route('/create/', methods=['POST'])
class CreateAdminMs(Resource):
    @admin_namespace.doc('create')
    @admin_namespace.doc(params={'user': 'Nombre de usuario', 'pass': 'Clave', 'token': 'token'})
    @admin_namespace.response(200, 'Usuario creado', return_payload_model)
    @admin_namespace.response(403, 'Error de acceso', return_payload_model)
    @admin_namespace.response(405, 'Error de token', return_payload_model)
    @admin_namespace.marshal_with(return_payload_model)
    def post(self):
        us = request.form.get("user", None)
        pw = request.form.get("pass", None)
        tk = request.form.get("token", None)

        code, _ = validate_token_admin(tk, PUBLIC_KEY)
        if code == HTTPStatus.OK:
            usuario_bbdd = Logins()
            usuario_bbdd.login = us
            usuario_bbdd.pasw = pw
            db.session.add(usuario_bbdd)
            db.session.commit()
            return_payload['message'] = True
            return return_payload

        abort(code)


@admin_namespace.route('/delete/', methods=['POST'])
class DeleteAdminMs(Resource):
    @admin_namespace.doc('delete')
    @admin_namespace.doc(params={'user': 'Nombre de usuario', 'pass': 'Clave', 'token': 'token'})
    @admin_namespace.response(200, 'Usuario borrado', return_payload_model)
    @admin_namespace.response(403, 'Error de acceso', return_payload_model)
    @admin_namespace.response(405, 'Error de token', return_payload_model)
    @admin_namespace.marshal_with(return_payload_model)
    def post(self):
        us = request.form.get("user", None)
        pw = request.form.get("pass", None)
        tk = request.form.get("token", None)

        code, _ = validate_token_admin(tk, PUBLIC_KEY)
        if code == HTTPStatus.OK:
            usuario_bbdd = Logins.query.filter_by(login=us, pasw=pw).first()
            if usuario_bbdd:
                usuario_bbdd.login = us
                usuario_bbdd.pasw = pw
                db.session.delete(usuario_bbdd)
                db.session.commit()
                return_payload['message'] = True
                return return_payload

            abort(HTTPStatus.METHOD_NOT_ALLOWED)

        abort(code)
