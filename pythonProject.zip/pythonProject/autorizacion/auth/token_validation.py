import jwt
from datetime import datetime, timedelta
from http import HTTPStatus
from auth.db import db, Logins
from auth.models import token_payload
from auth.config import TIME_VALID_TOKEN


def encode_token(data, private_key):
    return jwt.encode(data, private_key, algorithm='RS256')


def decode_token(token, public_key):
    return jwt.decode(token, public_key, algorithms='RS256')


def generate_token(usuario, password, private_key):
    """
    Crea un token para un usuario si conoce la clave y el nombre del usuario, tendrá una validez de dos días
    :param usuario:
    :param password:
    :param private_key:
    :return: http FORBIDDEN| OK, token|None
    """
    usuario_bbdd = Logins.query.filter_by(login=usuario, pasw=password).first()
    if usuario_bbdd:
        token_payload['login'] = usuario_bbdd.login
        token_payload['tipo'] = usuario_bbdd.tipo
        token_payload['iat'] = datetime.utcnow()
        token_payload['exp'] = datetime.utcnow() + timedelta(minutes=TIME_VALID_TOKEN)
        token = encode_token(token_payload, private_key)
        usuario_bbdd.token = token
        db.session.commit()
        return HTTPStatus.OK, f'{token}'

    return HTTPStatus.FORBIDDEN, None


def validate_token(token, public_key):
    """
    Valida el último token creado por el usuario
    :param token:
    :param public_key:
    :return: http METHOD_NOT_ALLOWED| OK, login|None
    """
    try:
        decoded_token = decode_token(token, public_key)
    except jwt.exceptions.DecodeError:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    except jwt.exceptions.ExpiredSignatureError:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    if 'exp' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'login' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'iat' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'tipo' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    usuario_bbdd = Logins.query.filter_by(login=decoded_token['login']).first()
    if not usuario_bbdd or token != usuario_bbdd.token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    return HTTPStatus.OK, decoded_token['login']


def logout_token(usuario):
    """
    Borra el token del usuario
    :param usuario:
    :return: http FORBIDDEN|OK, usuario|None
    """
    usuario_bbdd = Logins.query.filter_by(login=usuario).first()
    if usuario_bbdd:
        usuario_bbdd.token = ''
        db.session.commit()
        return HTTPStatus.OK, usuario
    return HTTPStatus.FORBIDDEN, None


def generate_token_admin(usuario, password, private_key):
    """
    Crea un token para un admin si conoce la clave y el nombre del usuario, tendrá una validez de dos días
    :param usuario:
    :param password:
    :param private_key:
    :return: http FORBIDDEN| OK, token|None
    """
    usuario_bbdd = Logins.query.filter_by(login=usuario, pasw=password).first()
    if usuario_bbdd and usuario_bbdd.tipo == Logins.ADMIN:
        token_payload['login'] = usuario_bbdd.login
        token_payload['tipo'] = usuario_bbdd.tipo
        token_payload['iat'] = datetime.utcnow()
        token_payload['exp'] = datetime.utcnow() + timedelta(minutes=TIME_VALID_TOKEN)
        token = encode_token(token_payload, private_key)
        usuario_bbdd.token = token
        db.session.commit()
        return HTTPStatus.OK, f'{token}'

    return HTTPStatus.FORBIDDEN, None


def validate_token_admin(token, public_key):
    """
    Valida el último token creado por el administrador
    :param token:
    :param public_key:
    :return: http METHOD_NOT_ALLOWED| OK, login|None
    """
    try:
        decoded_token = decode_token(token, public_key)
    except jwt.exceptions.DecodeError:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    except jwt.exceptions.ExpiredSignatureError:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    if 'exp' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'login' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'iat' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None
    if 'tipo' not in decoded_token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    usuario_bbdd = Logins.query.filter_by(login=decoded_token['login'], tipo=Logins.ADMIN).first()
    if not usuario_bbdd or token != usuario_bbdd.token:
        return HTTPStatus.METHOD_NOT_ALLOWED, None

    return HTTPStatus.OK, decoded_token['login']
