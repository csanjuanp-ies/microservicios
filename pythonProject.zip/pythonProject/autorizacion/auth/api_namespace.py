from http import HTTPStatus
from flask_restx import Namespace, Resource, abort
from flask import request
from auth.config import PUBLIC_KEY, PRIVATE_KEY
from auth.models import return_payload
from auth.token_validation import validate_token, generate_token, logout_token

api_namespace = Namespace('api', description='User API operations')

return_payload_model = api_namespace.model('Return', return_payload)


@api_namespace.route('/v1/login/')
class LoginMs(Resource):
    @api_namespace.doc('login')
    @api_namespace.doc(params={'user': 'Nombre de usuario', 'pass': 'Clave'})
    @api_namespace.response(200, 'Token creado', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        us = request.args.get("user", None)
        pw = request.args.get("pass", None)

        code, token = generate_token(us, pw, PRIVATE_KEY)
        if code == HTTPStatus.OK:
            return_payload['message'] = token
            return return_payload

        abort(code)


@api_namespace.route('/v1/validate/')
class ValidateMs(Resource):
    @api_namespace.doc('validate')
    @api_namespace.doc(params={'token': 'Token de validación'})
    @api_namespace.response(200, 'Validacion correcta', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.response(405, 'Error de token', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        tk = request.args.get("token", None)

        code, login = validate_token(tk, PUBLIC_KEY)
        if code == HTTPStatus.OK:
            return_payload['message'] = True
            return return_payload

        abort(code)


@api_namespace.route('/v1/logout/')
class LogoutMs(Resource):
    @api_namespace.doc('logout')
    @api_namespace.doc(params={'token': 'token de validación'})
    @api_namespace.response(200, 'Logout correcta', return_payload_model)
    @api_namespace.response(403, 'Error de acceso', return_payload_model)
    @api_namespace.response(405, 'Error de token', return_payload_model)
    @api_namespace.marshal_with(return_payload_model)
    def get(self):
        tk = request.args.get("token", None)

        code, login = validate_token(tk, PUBLIC_KEY)
        if code == HTTPStatus.OK:
            logout_token(login)
            return_payload['message'] = True
            return return_payload

        abort(code)
