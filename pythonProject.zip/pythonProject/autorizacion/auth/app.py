from flask import Flask
from flask_restx import Api
from auth.api_namespace import api_namespace
from auth.admin_namespace import admin_namespace
from auth.db import db, db_config

# import logging
# logger = logging.getLogger(__name__)
# logger.info('App init')  # Esta línea en cualquier parte del código para mandar al log

def create_app():

    application = Flask(__name__)
    api = Api(application, version='0.1', title='Autorizacion ms', description='ms de autorización')

    application.config['RESTPLUS_MASK_SWAGGER'] = False
    application.config.update(db_config)
    db.init_app(application)
    application.db = db

    api.add_namespace(api_namespace)
    api.add_namespace(admin_namespace)
    return application
