from flask_restx import fields

login_model = {
    'login': fields.Integer(),
    'pasw': fields.String(),
    'tipo': fields.String(),
    'token': fields.String(),
}

token_payload = {
            'login': fields.String(),
            'tipo': fields.String(),
            'iat': fields.DateTime(),
            'exp': fields.DateTime()
        }

return_payload = {
    'message': fields.String(),
}