import unittest
import auth.app
import auth.db


class TestBBDD(unittest.TestCase):
    def setUp(self) -> None:
        self.application = auth.app.create_app()
        self.application.app_context().push()

    def test_app(self):
        self.assertIsNotNone(self.application)

    def test_bbdd(self):
        self.assertIsNotNone(self.application.db)

    def test_select_user(self):
        USER = 'u'
        usuario = auth.db.Logins.query.filter_by(login='').first()
        self.assertIsNone(usuario)
        usuario = auth.db.Logins.query.filter_by(login=USER).first()
        self.assertEqual(USER, usuario.pasw)

    def test_insert_user(self):
        # Datos a insertar
        DATA = 'x'
        usuario_bbdd = auth.db.Logins()
        usuario_bbdd.login = DATA
        usuario_bbdd.pasw = DATA
        # Insertar en la BBDD
        self.application.db.session.add(usuario_bbdd)
        self.application.db.session.commit()
        # Comprobar los datos insertados
        usuario = auth.db.Logins.query.filter_by(login=DATA, pasw=DATA).first()
        self.assertEqual(usuario.login, DATA)
        self.assertEqual(usuario.pasw, DATA)
        # Restaurar la BBDD a su estado original
        self.application.db.session.delete(usuario_bbdd)
        self.application.db.session.commit()
        # Comprobar que la BBDD se ha quedado como debería
        usuario = auth.db.Logins.query.filter_by(login=DATA, pasw=DATA).first()
        self.assertIsNone(usuario)

    def test_update_user(self):
        # Datos a insertar
        DATA = 'x'
        DATA_NEW = 'yy'
        usuario_bbdd = auth.db.Logins()
        usuario_bbdd.login = DATA
        usuario_bbdd.pasw = DATA
        # Añadimos el usuario a la BBDD
        self.application.db.session.add(usuario_bbdd)
        self.application.db.session.commit()
        # Recogemos el usuario recién insertado para modificarlo
        usuario = auth.db.Logins.query.filter_by(login=DATA, pasw=DATA).first()
        # Nuevos datos modificados
        usuario.login = DATA_NEW
        usuario.pasw = DATA_NEW
        usuario.token = DATA_NEW
        usuario.tipo = auth.db.Logins.ADMIN
        self.application.db.session.commit()
        # Comprobamos si se han modificado los datos
        usuario = auth.db.Logins.query.filter_by(login=DATA_NEW, pasw=DATA_NEW).first()
        self.assertEqual(usuario.login, DATA_NEW)
        self.assertEqual(usuario.pasw, DATA_NEW)
        self.assertEqual(usuario.tipo, auth.db.Logins.ADMIN)
        self.assertEqual(usuario.token, DATA_NEW)
        # Restauramos la BBDD a su estado original
        self.application.db.session.delete(usuario)
        self.application.db.session.commit()
        # Comprobamos que la BBDD se ha quedado como debería
        usuario = auth.db.Logins.query.filter_by(login=DATA_NEW, pasw=DATA_NEW).first()
        self.assertIsNone(usuario)
        usuario = auth.db.Logins.query.filter_by(login=DATA, pasw=DATA).first()
        self.assertIsNone(usuario)
