from http import HTTPStatus
import requests
import json
import unittest
import auth.app
import auth.db
import auth.config
from unittest.mock import ANY
from auth.config import SRV_IP, SRV_PORT

from faker import Faker

fake = Faker()


class TestAdmin(unittest.TestCase):
    """
        Es necesario que el sevicio esté funcionando para hacer estos estos, ejectuar el wsgi.py
    """
    USER = PASS = 'a'
    URL_PATH_CREATE = '/admin/create/'
    URL_PATH_DELETE = '/admin/delete/'
    URL_PATH_LOGIN = '/admin/login/'

    def setUp(self) -> None:
        self.application = auth.app.create_app()
        self.application.app_context().push()
        usuario = auth.db.Logins.query.filter_by(login=TestAdmin.USER, pasw=TestAdmin.PASS).first()
        if usuario is None:
            usuario = auth.db.Logins()
            usuario.login = TestAdmin.USER
            usuario.pasw = TestAdmin.PASS
            self.application.db.session.commit()

    def test_app(self):
        self.assertIsNotNone(self.application)

    def test_bbdd(self):
        self.assertIsNotNone(self.application.db)

    def test_login_user_ok(self):
        new_data = {
            'user': TestAdmin.USER,
            'pass': TestAdmin.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_LOGIN}'
        respuesta = requests.post(url, data=new_data)

        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_user_pass_fail(self):
        new_data = {
            'user': fake.name(),
            'pass': fake.text(240),
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_LOGIN}'
        respuesta = requests.post(url, data=new_data)

        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_user_fail(self):
        new_data = {
            'user': fake.name(),
            'pass': TestAdmin.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_LOGIN}'
        respuesta = requests.post(url, data=new_data)

        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_pass_fail(self):
        new_data = {
            'user': TestAdmin.USER,
            'pass': fake.text(240),
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_LOGIN}'
        respuesta = requests.post(url, data=new_data)

        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def get_token(self):
        new_data = {
            'user': TestAdmin.USER,
            'pass': TestAdmin.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_LOGIN}'
        respuesta = requests.post(url, data=new_data)

        if HTTPStatus.OK == respuesta.status_code:
            result = json.loads(respuesta.text)
            return result['message']
        return None

    def test_create_delete_user_ok(self):
        token = self.get_token()
        data = {
            'user': 'x',
            'pass': 'x',
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_CREATE}'
        respuesta = requests.post(url, data=data)
        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_DELETE}'
        respuesta = requests.post(url, data=data)
        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_create_delete_user_token_fail(self):
        token = self.get_token()
        data = {
            'user': 'x',
            'pass': 'x',
            'token': token + "_",
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_CREATE}'
        respuesta = requests.post(url, data=data)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)

    def test_delete_user_user_fail(self):
        token = self.get_token()
        data = {
            'user': 'x1',
            'pass': 'x',
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_DELETE}'
        respuesta = requests.post(url, data=data)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)

    def test_delete_user_pass_fail(self):
        token = self.get_token()
        data = {
            'user': 'x',
            'pass': 'x1',
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAdmin.URL_PATH_DELETE}'
        respuesta = requests.post(url, data=data)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
