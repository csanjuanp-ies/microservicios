import datetime
from http import HTTPStatus
import unittest
import auth.app
import auth.db
import auth.config
import auth.token_validation as tk
from faker import Faker
import delorean

fake = Faker()

INVALID_PUBLIC_KEY = '''
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsyJ9HXVEYdf5axky6jMr
asfhBM0OnlQqPQAuFm06LwQP4pci9OrEffgOivBiGcblJIgskTE8X0ShVikHAQKK
GWjmyjJuQ1QFVk5050zxDNh12WvIl0NG1PSjlhw9gVP7lJgxgLdfXARTQTgw2TF9
kjHfik1zFQwZLaYzSSbtL1OB+VpCzu02ZGW0RiTDu83IfoVjEEBkmJMyOpU7Mm6V
jzoLevtSLLPzFsTroMCI5KhxSyrfCD6bOsW/6hiU45i1yLucrqSKDi32FAfFU+Hr
jiNC+MHB7Qn4+X5FEKRqykOjiB4PzLrmNR1UEUnJT+PBUAaYUX9in+p2lVRJ/6qs
+wIDAQAB
-----END PUBLIC KEY-----
'''


class TestTokenValidation(unittest.TestCase):
    def setUp(self) -> None:
        self.USER = self.PASS = 'u'
        self.USER_ADMIN = self.PASS_ADMIN = 'a'
        self.TIPO = 'U'
        self.application = auth.app.create_app()
        self.application.app_context().push()
        usuario = auth.db.Logins.query.filter_by(login=self.USER, pasw=self.PASS).first()
        if usuario is None:
            usuario = auth.db.Logins()
            usuario.login = self.USER
            usuario.pasw = self.PASS
            self.application.db.session.commit()

    def test_encode_and_decode(self):
        payload = {
            'example': 'payload',
        }

        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        assert payload == tk.decode_token(token, auth.config.PUBLIC_KEY)

    def test_app(self):
        self.assertIsNotNone(self.application)

    def test_generate_token_user_validate(self):
        code, token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        self.assertIsNotNone(token)
        self.assertEqual(HTTPStatus.OK, code)

    def test_generate_token_bad_user(self):
        code, token = tk.generate_token(self.USER + "1", self.PASS, auth.config.PRIVATE_KEY)
        self.assertIsNone(token)
        self.assertEqual(HTTPStatus.FORBIDDEN, code)

    def test_generate_token_bad_pass(self):
        code, token = tk.generate_token(self.USER, self.PASS + "1", auth.config.PRIVATE_KEY)
        self.assertIsNone(token)
        self.assertEqual(HTTPStatus.FORBIDDEN, code)

    def test_validate_token_token_valid(self):
        _, token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        code, user = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(user, self.USER)
        self.assertEqual(HTTPStatus.OK, code)

    def test_validate_token_key_invalid(self):
        token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        code, user = tk.validate_token(token, INVALID_PUBLIC_KEY)
        self.assertIsNone(user)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_token_invalid(self):
        # token inválido al añadir el _
        token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY + "_")
        code, user = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertIsNone(user)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_token(self):
        token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        usuario = auth.db.Logins.query.filter_by(login=self.USER, pasw=self.PASS).first()
        usuario.login = self.USER + "1"  # Forzar que el usuario no esté en la BBDD
        self.application.db.session.commit()
        code, user = tk.validate_token(token, auth.config.PUBLIC_KEY)
        usuario.login = self.USER
        self.application.db.session.commit()  # Restaurar la BBDD a su estado original
        self.assertIsNone(user)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_expired(self):
        expiry = delorean.parse('2018-05-17 13:47:33').datetime
        payload = {
            'login': self.USER,
            'iat': datetime.datetime.now(),
            'tipo': self.TIPO,
            'exp': expiry,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_user(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'iat': datetime.datetime.now(),
            'tipo': self.TIPO,
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_iat(self):
        payload = {
            'login': self.USER,
            'tipo': self.TIPO,
            'exp': datetime.datetime.now(),
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_tipo(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'login': self.USER,
            'iat': datetime.datetime.now(),
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_exp(self):
        payload = {
            'login': self.USER,
            'passw': self.PASS,
            'tipo': 'U',
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_no_login(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'login': fake.name(),
            'iat': datetime.datetime.now(),
            'tipo': 'U',
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_logout_token_user_validate(self):
        _, token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        code, user = tk.logout_token(self.USER)
        self.assertEqual(user, self.USER)
        self.assertEqual(HTTPStatus.OK, code)

    def test_logout_token_bad_user(self):
        _, token = tk.generate_token(self.USER, self.PASS, auth.config.PRIVATE_KEY)
        code, user = tk.logout_token(self.USER + "1")  # Forzar a que el usuario no exista
        self.assertIsNone(user)
        self.assertEqual(HTTPStatus.FORBIDDEN, code)

    #  =====================================================================
    #   Administrador
    #  =====================================================================
    def test_generate_token_admin_user_validate(self):
        code, token = tk.generate_token_admin(self.USER_ADMIN, self.PASS_ADMIN, auth.config.PRIVATE_KEY)
        self.assertIsNotNone(token)
        self.assertEqual(HTTPStatus.OK, code)

    def test_generate_token_admin_bad_user(self):
        code, token = tk.generate_token_admin(self.USER_ADMIN + "1", self.PASS_ADMIN, auth.config.PRIVATE_KEY)
        self.assertIsNone(token)
        self.assertEqual(HTTPStatus.FORBIDDEN, code)

    def test_generate_token_admin_bad_pass(self):
        code, token = tk.generate_token_admin(self.USER_ADMIN, self.PASS_ADMIN + "1", auth.config.PRIVATE_KEY)
        self.assertIsNone(token)
        self.assertEqual(HTTPStatus.FORBIDDEN, code)

    def test_validate_admin_token_expired(self):
        expiry = delorean.parse('2018-05-17 13:47:33').datetime
        payload = {
            'login': self.USER,
            'iat': datetime.datetime.now(),
            'tipo': self.TIPO,
            'exp': expiry,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_admin_no_user(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'iat': datetime.datetime.now(),
            'tipo': self.TIPO,
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_admin_no_iat(self):
        payload = {
            'login': self.USER,
            'tipo': self.TIPO,
            'exp': datetime.datetime.now(),
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_admin_no_tipo(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'login': self.USER,
            'iat': datetime.datetime.now(),
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_admin_no_exp(self):
        payload = {
            'login': self.USER,
            'passw': self.PASS,
            'tipo': 'U',
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)

    def test_validate_token_admin_no_login(self):
        time_next = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        payload = {
            'login': fake.name(),
            'iat': datetime.datetime.now(),
            'tipo': 'U',
            'exp': time_next,
        }
        token = tk.encode_token(payload, auth.config.PRIVATE_KEY)
        token = f'{token}'
        code, _ = tk.validate_token_admin(token, auth.config.PUBLIC_KEY)
        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, code)
