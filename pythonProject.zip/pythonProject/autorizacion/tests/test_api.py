from http import HTTPStatus
import requests
import json
import unittest
import auth.app
import auth.db
import auth.config
from unittest.mock import ANY
from auth.config import SRV_IP, SRV_PORT

from faker import Faker

fake = Faker()


class TestAPI(unittest.TestCase):
    """
        Es necesario que el sevicio esté funcionando para hacer estos estos, ejectuar el wsgi.py
    """
    USER = PASS = 'u'
    URL_PATH_LOGIN = '/api/v1/login/'
    URL_PATH_VALIDATION = '/api/v1/validate/'
    URL_PATH_LOGOUT = '/api/v1/logout/'

    def setUp(self) -> None:
        self.application = auth.app.create_app()
        self.application.app_context().push()
        usuario = auth.db.Logins.query.filter_by(login=TestAPI.USER, pasw=TestAPI.PASS).first()
        if usuario is None:
            usuario = auth.db.Logins()
            usuario.login = TestAPI.USER
            usuario.pasw = TestAPI.PASS
            self.application.db.session.commit()

    def test_app(self):
        self.assertIsNotNone(self.application)

    def test_bbdd(self):
        self.assertIsNotNone(self.application.db)

    def test_login_user_ok(self):
        new_data = {
            'user': TestAPI.USER,
            'pass': TestAPI.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGIN}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_user_pass_fail(self):
        new_data = {
            'user': fake.name(),
            'pass': fake.text(240),
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGIN}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_user_fail(self):
        new_data = {
            'user': fake.name(),
            'pass': TestAPI.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGIN}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_login_pass_fail(self):
        new_data = {
            'user': TestAPI.USER,
            'pass': fake.text(240),
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGIN}'
        respuesta = requests.get(url, params=new_data)


        self.assertEqual(HTTPStatus.FORBIDDEN, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def get_token(self):
        new_data = {
            'user': TestAPI.USER,
            'pass': TestAPI.PASS,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGIN}'
        respuesta = requests.get(url, params=new_data)
        if respuesta.status_code == HTTPStatus.OK:
            result = json.loads(respuesta.text)
            return result['message']
        return None

    def test_validate_ok(self):
        token = self.get_token()
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_VALIDATION}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': 'True'}
        self.assertEqual(result, expected)

    def test_validate_token_error(self):
        token = self.get_token() + "_"  # Forzar error
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_VALIDATION}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_validate_token_null(self):
        token = ""
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_VALIDATION}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_validate_token_fake(self):
        token = fake.text(458)
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_VALIDATION}'
        respuesta = requests.get(url, params=new_data)


        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_logout_ok(self):
        token = self.get_token()
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGOUT}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.OK, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': 'True'}
        self.assertEqual(result, expected)

    def test_logout_token_error(self):
        token = self.get_token() + "_"  # Forzar error
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGOUT}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_logout_token_null(self):
        token = ""
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGOUT}'
        respuesta = requests.get(url, params=new_data)


        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)

    def test_logout_token_fake(self):
        token = fake.text(458)
        new_data = {
            'token': token,
        }
        url = f'http://{SRV_IP}:{SRV_PORT}{TestAPI.URL_PATH_LOGOUT}'
        respuesta = requests.get(url, params=new_data)

        self.assertEqual(HTTPStatus.METHOD_NOT_ALLOWED, respuesta.status_code)
        result = json.loads(respuesta.text)
        expected = {'message': ANY}
        self.assertEqual(result, expected)
