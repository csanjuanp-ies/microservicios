import os

# Tiempo en minutos de validación del token
SRV_IP = os.environ.get('SRV_IP', '127.0.0.1')
SRV_PORT = os.environ.get('SRV_PORT', '8080')
SRV_IP_VALIDATION = os.environ.get('SRV_IP_VALIDATION', '127.0.0.1')
SRV_PORT_VALIDATION = os.environ.get('SRV_PORT_VALIDATION', '15000')
SRV_IP_RENTRADA = os.environ.get('SRV_IP_RENTRADA', '127.0.0.1')
SRV_PORT_RENTRADA = os.environ.get('SRV_PORT_RENTRADA', '15001')
SRV_IP_RSALIDA = os.environ.get('SRV_IP_RSALIDA', '127.0.0.1')
SRV_PORT_RSALIDA = os.environ.get('SRV_PORT_RSALIDA', '15002')

URL_PATH_VALIDATION = '/api/v1/validate/'
URL_PATH_LOGIN = '/api/v1/login/'
URL_PATH_GET_ROWS = '/api/v1/get_rows/'
URL_PATH_INSERT_ROWS = '/api/v1/insert_row/'
URL_PATH_UPDATE_ROWS = '/api/v1/update_row/'
URL_PATH_GET_ASUNTOS = '/api/v1/get_asuntos/'
URL_PATH_GET_DESTINOS = '/api/v1/get_destinos/'
