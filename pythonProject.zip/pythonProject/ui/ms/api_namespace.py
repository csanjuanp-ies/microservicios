import functools
import os
from http import HTTPStatus
from ms.config import \
    SRV_IP_VALIDATION, SRV_PORT_VALIDATION, \
    SRV_IP_RENTRADA, SRV_PORT_RENTRADA, \
    SRV_IP_RSALIDA, SRV_PORT_RSALIDA, \
    URL_PATH_LOGIN, URL_PATH_GET_ROWS, URL_PATH_INSERT_ROWS, URL_PATH_UPDATE_ROWS, \
    URL_PATH_GET_ASUNTOS, URL_PATH_GET_DESTINOS
import requests
from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for, make_response
import json
import io
import csv
import logging

logging.basicConfig(level=os.environ.get("LOGLEVEL", "INFO"))
logger = logging.getLogger(__name__)

bp = Blueprint('ui', __name__, url_prefix='/')


def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.token is None:
            return redirect(url_for('ui.login'))

        return view(**kwargs)

    return wrapped_view


def get_table_aux(rentrada=True, asuntos=True):
    new_data = {
        'token': g.token,
    }
    if rentrada:
        url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}'
    else:
        url = f'http://{SRV_IP_RSALIDA}:{SRV_PORT_RSALIDA}'
    if asuntos:
        url += f"{URL_PATH_GET_ASUNTOS}"
    else:
        url += f"{URL_PATH_GET_DESTINOS}"
    try:
        logger.info('get_table_aux:'+url)
        respuesta = requests.get(url, params=new_data)
    except Exception as e:
        logger.info('get_table_aux:' + str(e))
        return []
    logger.info('get_table_aux:' + str(respuesta.content))
    if respuesta.status_code == HTTPStatus.OK:
        return json.loads(json.loads(respuesta.content)['message'])
    return []

@bp.before_app_request
def load_logged_in_user():
    token = session.get('token')

    if token is None:
        g.token = None
    else:
        g.token = token


@bp.route('/')
def index():
    return render_template('base.html')


@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        error = None

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'

        if error is None:
            session.clear()
            # Intentamos validar contra el servidor de validación
            new_data = {
                'user': username,
                'pass': password,
            }
            url = f'http://{SRV_IP_VALIDATION}:{SRV_PORT_VALIDATION}{URL_PATH_LOGIN}'
            try:
                logger.info('login:' + url)
                respuesta = requests.get(url, params=new_data)
            except Exception as e:
                return redirect(url_for("ui.login"))
            if respuesta.status_code == HTTPStatus.OK:
                session['token'] = json.loads(respuesta.content)['message']
            return redirect(url_for("ui.index"))

        flash(error)

    return render_template("login.html")


@bp.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('ui.index'))


@bp.route('/exportar', methods=('GET', 'POST'))
@login_required
def exportar():
    if request.method == 'POST':
        new_data = {
            'token': g.token,
        }
        url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}{URL_PATH_GET_ROWS}'
        try:
            logger.info('exportar_1:' + url)
            respuesta = requests.get(url, params=new_data)
        except Exception as e:
            logger.info('exportar_2:' + str(e))
            return redirect(url_for("ui.index"))
        logger.info('exportar_3:' + str(respuesta.content))
        if respuesta.status_code == HTTPStatus.OK:
            # La respuesta es json, pero el mensaje también lo es, por eso dos conversiones
            data = json.loads(json.loads(respuesta.content)['message'])
            si = io.StringIO()
            cw = csv.writer(si)
            imprimir_cabecera = True
            for linea in data:
                if imprimir_cabecera:
                    cw.writerow(linea.keys())
                    imprimir_cabecera = False
                cw.writerow(linea.values())
            output = make_response(si.getvalue())
            output.headers["Content-Disposition"] = "attachment; filename=export.csv"
            output.headers["Content-type"] = "text/csv"
            return output

    return render_template("exportar.html")


@bp.route('/rentrada/listado')
@login_required
def rentrada_listado():
    new_data = {
        'token': g.token,
    }
    url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}{URL_PATH_GET_ROWS}'
    try:
        logger.info('rentrada_listado:' + url)
        respuesta = requests.get(url, params=new_data)
    except Exception as e:
        return redirect(url_for("ui.index"))
    if respuesta.status_code == HTTPStatus.OK:
        # La respuesta es json, pero el mensaje también lo es, por eso dos conversiones
        data = json.loads(json.loads(respuesta.content)['message'])
        return render_template("re_listado.html", data=data)
    return render_template("re_listado.html")


@bp.route('/rentrada/insertar', methods=('GET', 'POST'))
@login_required
def rentrada_insertar():
    if request.method == 'POST':
        new_data = {
            'token': g.token,
            'fecha': request.form['fecha'],
            'asunto': request.form['asunto'],
            'asuntootro': request.form['asuntootro'],
            'destino': request.form['destino'],
            'destinootro': request.form['destinootro'],
            'interesado': request.form['interesado'],
            'resumen': request.form['resumen'],
            'observaciones': request.form['observaciones'],
            'mmod': request.form['mmod']
        }
        if len(request.form['fecham']):
            new_data['fecham'] = request.form['fecham']
        url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}{URL_PATH_INSERT_ROWS}'
        try:
            logger.info('rentrada_insertar:' + url)
            respuesta = requests.get(url, params=new_data)
        except Exception as e:
            return redirect(url_for("ui.index"))
        if respuesta.status_code == HTTPStatus.OK:
            return redirect(url_for("ui.rentrada_listado"))

    return render_template("re_insertar.html", asuntos=get_table_aux(), destinos=get_table_aux(asuntos=False))


@bp.route('/rentrada/modificar/<int:id>/', methods=('GET', 'POST'))
@login_required
def rentrada_modificar(id):
    data = None
    if request.method == 'POST':
        new_data = {
            'token': g.token,
            'id': id,
            'fecha': request.form['fecha'],
            'asunto': request.form['asunto'],
            'asuntootro': request.form['asuntootro'],
            'destino': request.form['destino'],
            'destinootro': request.form['destinootro'],
            'interesado': request.form['interesado'],
            'resumen': request.form['resumen'],
            'observaciones': request.form['observaciones'],
            'fecham': request.form['fecham'],
            'mmod': request.form['mmod']
        }
        url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}{URL_PATH_UPDATE_ROWS}{str(id)}/'
        try:
            logger.info('rentrada_modificar_post:' + url)
            respuesta = requests.get(url, params=new_data)
        except Exception as e:
            return redirect(url_for("ui.index"))
        if respuesta.status_code == HTTPStatus.OK:
            return redirect(url_for("ui.rentrada_listado"))

    new_data = {
        'token': g.token,
    }
    url = f'http://{SRV_IP_RENTRADA}:{SRV_PORT_RENTRADA}{URL_PATH_GET_ROWS}{str(id)}/'
    try:
        logger.info('rentrada_modificar_get:' + url)
        respuesta = requests.get(url, params=new_data)
    except Exception as e:
        return redirect(url_for("ui.index"))
    if respuesta.status_code == HTTPStatus.OK:
        data = json.loads(json.loads(respuesta.content)['message'])[0]

    return render_template("re_modificar.html", data=data, asuntos=get_table_aux(), destinos=get_table_aux(asuntos=False))


@bp.route('/rsalida/listado')
@login_required
def rsalida_listado():
    new_data = {
        'token': g.token,
    }
    url = f'http://{SRV_IP_RSALIDA}:{SRV_PORT_RSALIDA}{URL_PATH_GET_ROWS}'
    try:
        respuesta = requests.get(url, params=new_data)
    except Exception as e:
        return redirect(url_for("ui.index"))
    if respuesta.status_code == HTTPStatus.OK:
        # La respuesta es json, pero el mensaje también lo es, por eso dos conversiones
        data = json.loads(json.loads(respuesta.content)['message'])
        return render_template("rs_listado.html", data=data)
    return render_template("rs_listado.html")


@bp.route('/rsalida/insertar', methods=('GET', 'POST'))
@login_required
def rsalida_insertar():
    if request.method == 'POST':
        new_data = {
            'token': g.token,
            'fecha': request.form['fecha'],
            'destino': request.form['destino'],
            'destinootro': request.form['destinootro'],
            'interesado': request.form['interesado'],
            'observaciones': request.form['observaciones'],
            'mmod': request.form['mmod']
        }
        if len(request.form['fecham']):
            new_data['fecham'] = request.form['fecham']
        url = f'http://{SRV_IP_RSALIDA}:{SRV_PORT_RSALIDA}{URL_PATH_INSERT_ROWS}'
        try:
            respuesta = requests.get(url, params=new_data)
        except Exception as e:
            return redirect(url_for("ui.index"))
        if respuesta.status_code == HTTPStatus.OK:
            return redirect(url_for("ui.rsalida_listado"))
    return render_template("rs_insertar.html", destinos=get_table_aux(rentrada=False, asuntos=False))


@bp.route('/rsalida/modificar/<int:id>/', methods=('GET', 'POST'))
@login_required
def rsalida_modificar(id):
    data = None
    if request.method == 'POST':
        new_data = {
            'token': g.token,
            'id': id,
            'fecha': request.form['fecha'],
            'destino': request.form['destino'],
            'destinootro': request.form['destinootro'],
            'interesado': request.form['interesado'],
            'observaciones': request.form['observaciones'],
            'fecham': request.form['fecham'],
            'mmod': request.form['mmod']
        }
        url = f'http://{SRV_IP_RSALIDA}:{SRV_PORT_RSALIDA}{URL_PATH_UPDATE_ROWS}{str(id)}/'
        try:
            respuesta = requests.get(url, params=new_data)
        except Exception as e:
            return redirect(url_for("ui.index"))
        if respuesta.status_code == HTTPStatus.OK:
            return redirect(url_for("ui.rsalida_listado"))

    new_data = {
        'token': g.token,
    }
    url = f'http://{SRV_IP_RSALIDA}:{SRV_PORT_RSALIDA}{URL_PATH_GET_ROWS}{str(id)}/'
    try:
        respuesta = requests.get(url, params=new_data)
    except Exception as e:
        return redirect(url_for("ui.index"))
    if respuesta.status_code == HTTPStatus.OK:
        data = json.loads(json.loads(respuesta.content)['message'])[0]

    return render_template("rs_modificar.html", data=data, destinos=get_table_aux(rentrada=False, asuntos=False))
