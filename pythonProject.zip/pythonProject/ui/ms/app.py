from flask import Flask
from ms.api_namespace import bp as bp_api


def create_app():
    application = Flask(__name__)

    application.config.from_mapping(
        SECRET_KEY='dev',
    )
    application.register_blueprint(bp_api)

    return application
