<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  $_SESSION['frm_departamentos']=$_POST['departamento'];
  $_SESSION['frm_ubicacion']=$_POST['ubicacion'];
  $_SESSION['grabado_ok']=grabar_articulo_bbdd();
  header("Location: anadir.php");
}
else //No validado como usuario
  header("Location: index.php");
?>