<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  include("cabecera.html");
  ?>

  <script type="text/javascript" src="typeahead.js"></script>
  <div class="container">
    <div class="col-md-6 order-md-1">
      <h4 class="mb-3 font-weight-normal">Modificar Registro de Salida</h4>
    </div>
    <?php
    $registro = get_registro_data($_POST['id'], "rsalida");
    ?>

    <form class="needs-validation" action="modificar_rs_bbdd.php" method="post">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="referencia">Referencia</label>
                <input type="text" class="form-control" name="referencia" id="referencia" required readonly
                       value="<?php echo $registro['Referencia']; ?>">
                <div class="invalid-feedback">
                    La referencia es obligatoria.
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <label for="Fecha">Fecha</label>
                <input type="date" class="form-control" id="fecha" name="fecha" required value="<?php
                echo explode(" ", $registro['Fecha'])[0];
                ?>">
                <div class="invalid-feedback">
                    La Fecha es necesaria.
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="destino">Destino</label>
                <div class="input-group">
                    <select class="custom-select d-block w-100" id="destino" name="destino" required>
                        <?php
                        $val=$registro['Destino'];
                        echo get_table_data_select("sdestino", $val);
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <hr class="mb-4">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="interesado">Interesado</label>
                <input type="text" class="form-control" name="interesado" id="interesado" required value="<?php echo $registro['Interesado']; ?>">
                <div class="invalid-feedback">
                    El interesado es obligatorio.
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <label for="observaciones">Obsevaciones</label>
                <textarea type="text" class="form-control" id="observaciones" name="observaciones"><?php echo $registro['Observaciones']; ?></textarea>
            </div>
        </div>
        <hr class="mb-4">


        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="destinootro">Otro Destino</label>
                <input type="text" class="form-control" id="destinootro" name="destinootro" value="<?php echo $registro['DestinoOtro']; ?>">
            </div>
        </div>

        <hr class="mb-4">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="fecham">Fecha de modificación</label>
                <input type="date" class="form-control" id="fecham" name="fecham" value="<?php echo $registro['fecham']; ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label for="mmod">Motivo de modificación</label>
                <input type="text" class="form-control" id="mmod" name="mmod" value="<?php echo $registro['mmod']; ?>">
            </div>
        </div>

        <button class="btn btn-primary btn-lg btn-block">Grabar</button>
    </form>
  </div>
    <script type="text/javascript">
        $('#interesado').typeahead({
            source: function (query, result) {
                $.ajax({
                    minLength: 1,
                    url: "acelerator.php",
                    data: 'tbl=rsalida&fld=Interesado&query=' + query,
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
                        result($.map(data, function (item) {
                            return item;
                        }));
                    }
                });
            },
            minLength: 1
        });
    </script>
  <?php
  include("pie.html");
}
else //No validado como usuario
  header("Location: index.php");
?>