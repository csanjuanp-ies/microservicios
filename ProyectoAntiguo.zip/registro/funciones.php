<?php
error_reporting(E_ERROR | E_PARSE);

/**
 * @author César San Juan Pastor
 * @license  GPL
 * @version 0.1
 */
function validado(){
  if (!isset($_SESSION['log']) || $_SESSION['log']==false)
    return false;
  else
    return true;
}

function validar($pw){
  return $pw==CL;
}



function get_table_data_select($table, $id=0){
  $ret = "";
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
  }
  $sql = "SELECT id,descri FROM " . $table ." ORDER BY descri";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $ret .= "<option value='" . $row["id"] . "'";
      if ($row['id'] == $id) $ret.= " selected ";
      $ret .= ">". ($row["descri"])."</option>\n";
    }
  }
  $conn->close();
  return $ret;
}

function get_table_data_next_id($table){
    $ret = "";
    $conn = new mysqli(HS, US, PW, BD);
    $conn->set_charset('utf8');
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }
    $sql = "SELECT MAX(Referencia) as id  FROM " . $table;
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $ret = $row["id"] + 1;
    }
    $conn->close();
    return $ret;
}

function grabar_articulo_bbdd($table="rentrada"){
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
  }
  $referencia = $_POST['referencia'];
  $fecha = $_POST['fecha'] . " ". date("h:i:s");
  $destino = $_POST['destino'];
  $destinootro = $_POST['destinootro'];;
  $interesado = $_POST['interesado'];
  $observaciones = $_POST['observaciones'];
  $fecham = $_POST['fecham'];
  $mmod = $_POST['mmod'];
  if ($table == "rentrada") {
      $asunto = $_POST['asunto'];
      $asutnootro = $_POST['asuntootro'];
      $resumen = $_POST['resumen'];

      $sql = "INSERT INTO $table 
            (Referencia, Fecha, Asunto, AsuntoOtro, Destino, DestinoOtro,
            Interesado, Resumen, Observaciones, fecham, mmod)
        VALUES
            ($referencia,'$fecha',$asunto,'$asutnootro', $destino,'$destinootro',
            '$interesado','$resumen','$observaciones','$fecham','$mmod')";
  }
  else if ($table == "rsalida") {
    $sql = "INSERT INTO $table 
        (Referencia, Fecha,  Destino, DestinoOtro,
        Interesado, Observaciones, fecham, mmod)
    VALUES
        ($referencia,'$fecha', $destino,'$destinootro',
        '$interesado','$observaciones','$fecham','$mmod')";
  }
  $conn->query($sql);
  $ret = $conn->errno;
  $conn->close();
  return $ret;
}

function get_registro_data($id, $table="rentrada"){
  $ret = [];
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
  }
  $sql = "SELECT * FROM $table WHERE Referencia =" . $id;
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $ret = $row;
  }
  $conn->close();
  return $ret;
}

function modificar_articulo_bbdd($table="rentrada"){
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
  }

    $referencia = $_POST['referencia'];
    $fecha = $_POST['fecha'] . " ". date("h:i:s");
    $destino = $_POST['destino'];
    $destinootro = $_POST['destinootro'];;
    $interesado = $_POST['interesado'];
    $observaciones = $_POST['observaciones'];
    $fecham = $_POST['fecham'];
    $mmod = $_POST['mmod'];

    if ($table == "rentrada") {
        $asunto = $_POST['asunto'];
        $asutnootro = $_POST['asuntootro'];
        $resumen = $_POST['resumen'];
        $sql = "UPDATE $table  SET
                    Fecha='$fecha', Asunto=$asunto,
                    AsuntoOtro='$asutnootro', Destino=$destino, DestinoOtro='$destinootro',
                    Interesado = '$interesado', Resumen = '$resumen', Observaciones='$observaciones',
                    fecham = '$fecham', mmod = '$mmod'  
                WHERE Referencia =".$_POST['referencia'];
    }
    else if ($table == "rsalida") {
        $sql = "UPDATE $table  SET
                    Fecha='$fecha',  Destino=$destino, DestinoOtro='$destinootro',
                    Interesado = '$interesado',  Observaciones='$observaciones',
                    fecham = '$fecham', mmod = '$mmod'  
                WHERE Referencia =".$_POST['referencia'];
    }

  $conn->query($sql);
  $ret = $conn->errno;
  $conn->close();
  return $ret;
}
