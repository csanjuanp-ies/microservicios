<?php
/**
 * @author César San Juan Pastor
 * @license  GPL
 * @version 0.1
 */
define("HS","localhost");
define("US","rt");
define("PW","rt");
define("BD","registro");
define("CL","registro");
