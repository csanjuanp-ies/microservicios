<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  modificar_articulo_bbdd("rsalida");
  header("Location: listados_rs.php");
}
else //No validado como usuario
  header("Location: index.php");
?>