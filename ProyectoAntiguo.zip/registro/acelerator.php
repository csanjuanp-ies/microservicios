<?php
session_start();
include("funciones.php");
$json = array();
if (validado()) {
  include("const.php");
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  $keyword = strval($_REQUEST['query']);
  $field = strval($_REQUEST['fld']);
  $tabla = strval($_REQUEST['tbl']);
  $search_param = "{$keyword}%";
  $sql = "SELECT DISTINCT {$field} AS des FROM {$tabla} WHERE {$field} LIKE '$search_param'";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $json[] = $row["des"];
    }
  }
  $conn->close();
}
echo json_encode($json);


