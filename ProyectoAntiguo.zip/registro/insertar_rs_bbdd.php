<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  $_SESSION['grabado_ok']=grabar_articulo_bbdd("rsalida");
  header("Location: insertar_rs.php");
}
else //No validado como usuario
  header("Location: index.php");
?>