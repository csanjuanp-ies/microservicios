<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  include("cabecera.html");
  ?>

    <div class="container">
        <div class="col-md-8 order-md-1">
            <h4 class="mb-3 font-weight-normal">Listado Registro Entrada</h4>
        </div>
        <hr class="mb-4">
          <form action="modificar_re.php" method="post" id="frmModificar" name="frmModificar">
            <input type="hidden" name="id" id="id" value="-1">
            <table id="tablaDatos" class="table table-striped table-bordered table-sm">
                <thead>
                <tr>
                    <th class="th-sm">Referencia</th>
                    <th class="th-sm">Fecha</th>
                    <th class="th-sm">Asunto</th>
                    <th class="th-sm">Destino</th>
                    <th class="th-sm">Interesado</th>
                    <th class="th-sm">Otro Destino</th>
                    <th class="th-sm">Fecha Modificación</th>
                    <th class="th-sm">Modificación</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th class="th-sm">Referencia</th>
                    <th class="th-sm">Fecha</th>
                    <th class="th-sm">Asunto</th>
                    <th class="th-sm">Destino</th>
                    <th class="th-sm">Interesado</th>
                    <th class="th-sm">Otro Destino</th>
                    <th class="th-sm">Fecha Modificación</th>
                    <th class="th-sm">Modificación</th>
                </tr>
                </tfoot>
             </table>
          </form>
    </div>
    <script type="text/javascript">
        $(document).ready( function () {
            $('#tablaDatos tfoot th').each( function () {
                var title = $(this).text();
                $(this).html( '<input type="text" placeholder="por '+title+'" />' );
            } );
            let tabla = $('#tablaDatos').DataTable({
                "dom": 'Bflrtip',
                "responsive": true,
                "language": {
                    processing:     "Procesando...",
                    search:         "Buscar:",
                    lengthMenu:     "Hay _MENU_ elementos",
                    info:           "Del registro _START_ al _END_ de _TOTAL_  registros",
                    infoEmpty:      "registro 0 de 0 registros",
                    infoFiltered:   "(filtrado de _MAX_ del total)",
                    infoPostFix:    "",
                    loadingRecords: "Cargando...",
                    zeroRecords:    "No hay registros",
                    emptyTable:     "Sin registros",
                    paginate: {
                        first:      "Primero",
                        previous:   "Anterior",
                        next:       "Siguiente",
                        last:       "Último"
                    },
                    aria: {
                        sortAscending:  ": orden ascendente",
                        sortDescending: ": ordend descendente"
                    }
                },
                "buttons": [
                    'copy', 'pdf', 'print'
                ],
                "ajax": {
                    url: 'data_re.php'
                },
                "initComplete": function () {
                    this.api().columns().every( function () {
                        var that = this;

                        $( 'input', this.footer() ).on( 'keyup change clear', function () {
                            if ( that.search() !== this.value ) {
                                that
                                    .search( this.value )
                                    .draw();
                            }
                        } );
                    } );
                }
            });

            $('#tablaDatos tbody').on('click', 'td', function (event) {
                let id = event.target.parentNode.childNodes[0].innerText;
                $('#id').val(id)
                document.frmModificar.submit();
            } );




        } );


    </script>
<?php
  include("pie.html");
}
else //No validado como usuario
  header("Location: index.php");
?>