<?php
session_start();
include("const.php");
include("funciones.php");
include("cabecera.html");
?>

<div class="container">
    <div class="col-md-8 order-md-1">
        <h4 class="mb-3 font-weight-normal">Entrada al sistema</h4>
    </div>

    <form class="needs-validation" novalidate="" action="validar.php" method="post">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="clave">Clave</label>
                <input type="password" class="form-control" id="clave" name="clave" placeholder="" value="" required="">
                <div class="invalid-feedback">
                    La clave es necesaria.
                </div>
            </div>
        </div>


        <hr class="mb-4">
        <button class="btn btn-primary btn-lg btn-block" type="submit">Validar en el sistema</button>
    </form>
</div>

<?php
include("pie.html");
?>