<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  modificar_articulo_bbdd("rentrada");
  header("Location: listados_re.php");
}
else //No validado como usuario
  header("Location: index.php");
?>