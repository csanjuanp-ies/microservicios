<?php
session_start();
include("const.php");
include("funciones.php");
$clave =$_POST["clave"]??'-1';
if (validar($clave))
  $_SESSION['log'] = true;
else
  unset($_SESSION['log']);
header("Location: index.php");