<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
        $filename = "phpzag_data_export_".date('Ymd') . ".xls";
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        $show_coloumn = false;

        $conn = new mysqli(HS, US, PW, BD);

        //Datols del centro
        $sql = "SELECT * FROM datoscentro;";

        $result = $conn->query($sql);
        echo "Datos del centro" . "\n";
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_array( MYSQLI_ASSOC)) {
                if(!$show_coloumn) {
                    // display field/column names in first row
                    echo implode("\t", array_keys($row)) . "\n";
                    $show_coloumn = true;
                }
                echo implode("\t", array_values($row)) . "\n";
            }
        }

        //Registro entrada
        $show_coloumn = false;
        $sql = "SELECT rentrada.*,
            easunto.descri AS Asunto_des, edestino.descri AS Destino_des
            FROM rentrada,easunto,edestino
            WHERE easunto.id = rentrada.Asunto AND edestino.id=rentrada.Destino";
        $sql .= ' ORDER BY Referencia ';

        $result = $conn->query($sql);
        echo "\nRegistro Entrada" . "\n";
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_array( MYSQLI_ASSOC)) {
                if(!$show_coloumn) {
                    // display field/column names in first row
                    echo implode("\t", array_keys($row)) . "\n";
                    $show_coloumn = true;
                }
                echo implode("\t", array_values($row)) . "\n";
            }
        }
        //Registro salida
        $show_coloumn = false;
        echo "\nRegistro Salida" . "\n";
        $sql = "SELECT rsalida.*,
                sdestino.descri AS Destino_des
                FROM rsalida,sdestino
                WHERE  sdestino.id=rsalida.Destino";
        $sql .= ' ORDER BY Referencia ';

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_array( MYSQLI_ASSOC)) {
                if(!$show_coloumn) {
                    // display field/column names in first row
                    echo implode("\t", array_keys($row)) . "\n";
                    $show_coloumn = true;
                }
                echo implode("\t", array_values($row)) . "\n";
            }
        }
        $conn->close();
}
else //No validado como usuario
  header("Location: index.php");
?>