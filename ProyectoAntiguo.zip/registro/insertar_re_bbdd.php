<?php
session_start();
include("const.php");
include("funciones.php");
if (validado()){
  $_SESSION['grabado_ok']=grabar_articulo_bbdd();
  header("Location: insertar_re.php");
}
else //No validado como usuario
  header("Location: index.php");
?>