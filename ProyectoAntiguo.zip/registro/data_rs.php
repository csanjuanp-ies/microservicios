<?php
session_start();
include("const.php");
include("funciones.php");
$ret = "{\"data\":";
if (validado()) {
  $todo = $_GET['todo'] ?? false;
  include("const.php");
  $conn = new mysqli(HS, US, PW, BD);
  $conn->set_charset('utf8');
  $sql = "SELECT rsalida.Referencia AS id,Fecha,
       sdestino.descri AS Destino,
       Interesado,Observaciones, DestinoOtro,fecham, mmod 
       FROM rsalida,sdestino
       WHERE  sdestino.id=rsalida.Destino";
  // if (!$todo) $sql .= " AND fecha_baja is NULL";
  $sql .= ' ORDER BY id ';
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_array( MYSQLI_NUM)) {
      $json[] = $row;
    }
  }
  $conn->close();

  $ret .= json_encode($json) . "}";
  echo $ret;
}