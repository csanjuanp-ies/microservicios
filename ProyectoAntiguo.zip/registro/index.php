<?php
session_start();
include("const.php");
include("funciones.php");
include("cabecera.html");
?>

<div class="container"></div>

<?php
include("pie.html");
?>