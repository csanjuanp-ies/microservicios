<?php
session_start();
unset($_SESSION['log']);
unset($_SESSION['frm_departamentos']);
unset($_SESSION['frm_ubicacion']);
unset($_SESSION['grabado_ok']);
header("Location: index.php");